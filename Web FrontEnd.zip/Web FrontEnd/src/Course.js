import React from "react";

export default class Course extends React.Component{
    render()
    {
        return(
            <h1>COURSE COMPONENT</h1>
        )
    }
}