export const variables = {
    API_URL: "https://jsonplaceholder.typicode.com"
}