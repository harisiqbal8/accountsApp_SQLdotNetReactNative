import React from "react";

export default class Home extends React.Component{
    render()
    {
        return(
            <h1>HOME COMPONENT</h1>
        )
    }
}