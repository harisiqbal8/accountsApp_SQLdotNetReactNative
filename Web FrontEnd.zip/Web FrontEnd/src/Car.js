import React from "react";


export default function CarComponent() {
    return(
        <h1>Car Component</h1>
    )
}