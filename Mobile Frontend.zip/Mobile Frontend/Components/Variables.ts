export const Variables = {
    API_URL: "https://63e3-2407-aa80-15-31dc-8cbd-6e7d-b60a-ba68.ngrok-free.app"
}