insert into tbl_Fixed values ('haris', 1),( 'junaid', 1 ),
('bilal', 1)

insert into tbl_MasterAccount values (1, 'Cash in Hand' , 1)


select *from tbl_MasterAccount

select *from tbl_Fixed